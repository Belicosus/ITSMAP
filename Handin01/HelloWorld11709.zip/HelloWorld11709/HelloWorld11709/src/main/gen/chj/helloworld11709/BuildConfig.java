/** Automatically generated file. DO NOT MODIFY */
package chj.helloworld11709;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}